# ------------------------------------------------------------
# Push-Pull Voltage Level Shifter Transfer Characteristic Plot
# ------------------------------------------------------------
# Devices:
#   Q1 = 2N3906 (PNP)
#   Q2 = 2N3904 (NPN)
#   Rbase1 = 4.7kΩ
#   Rbase2 = 4.7kΩ
#   Vsupply = 3.3V
#   Input range = 0–5V
#
# The program computes approximate base currents, source/sink
# currents, and derives a smooth transfer curve between 0 V and 3.3 V.
# ------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt

# --- Circuit Parameters ---
Vs = 3.3           # Supply voltage (V)
Rb1 = 4.7e3        # Base resistor for PNP (Ω)
Rb2 = 4.7e3        # Base resistor for NPN (Ω)
Vbe = 0.7          # Base-emitter drop for NPN (V)
Veb = 0.7          # Emitter-base drop for PNP (V)
Vcesat = 0.2       # Collector-emitter saturation voltage (V)
beta_sat = 10      # Effective beta in saturation

# --- Output limits ---
Vout_high = Vs - Vcesat
Vout_low = Vcesat

# --- Sweep VIN from 0 V to 5 V ---
VIN = np.linspace(0, 5, 501)

# --- Compute base currents (forward bias only) ---
# PNP conducts when VIN < (Vs − Veb)
I_b1 = np.maximum((Vs - Veb - VIN) / Rb1, 0.0)  # A
# NPN conducts when VIN > Vbe
I_b2 = np.maximum((VIN - Vbe) / Rb2, 0.0)       # A

# --- Estimate collector source/sink capabilities ---
I_source = beta_sat * I_b1   # current the PNP can source (A)
I_sink   = beta_sat * I_b2   # current the NPN can sink (A)

# --- Combine into a weighted output voltage ---
I_total = I_source + I_sink
Vout = np.where(I_total > 0,
                (I_source * Vout_high + I_sink * Vout_low) / I_total,
                Vout_high)

# --- Plot transfer characteristic ---
plt.figure(figsize=(8, 5))
plt.plot(VIN, Vout, color='blue', linewidth=2)
plt.title("Push-Pull Level Shifter Transfer Characteristic")
plt.xlabel("Input Voltage VIN (V)")
plt.ylabel("Output Voltage VOUT (V)")
plt.grid(True)
plt.ylim(-0.1, Vs + 0.2)
plt.xlim(0, 5)
plt.tight_layout()
plt.show()

# --- Optional: Plot base and estimated collector currents ---
plt.figure(figsize=(8, 5))
plt.plot(VIN, I_b1 * 1e3, label="PNP Base Current (mA)")
plt.plot(VIN, I_b2 * 1e3, label="NPN Base Current (mA)")
plt.plot(VIN, I_source * 1e3, '--', label="PNP Source Current (mA)")
plt.plot(VIN, I_sink * 1e3, '--', label="NPN Sink Current (mA)")
plt.title("Base and Estimated Source/Sink Currents vs VIN")
plt.xlabel("Input Voltage VIN (V)")
plt.ylabel("Current (mA)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

print("Simulation complete.")
