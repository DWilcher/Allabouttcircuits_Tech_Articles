// -----------------------------------------------------------------------------
// E-Ink Paper HMI Display synchronized with external CONTROL SIGNAL input
// HIGH output -> Display "CONTROL SIGNAL : ON"
// LOW output  -> Display "CONTROL SIGNAL : OFF"
// The display updates only when the input state changes
// -----------------------------------------------------------------------------

#include <Arduino.h>
#include "EPD.h"  // E-Paper Display library

// Frame buffer for E-Ink display (size depends on your panel resolution)
uint8_t ImageBW[27200];

// GPIO pin connected to Arduino output (CONTROL SIGNAL line)
const int EInk_GPIO3_Pin = 3;

// Update interval for checking input state (milliseconds)
const unsigned long checkInterval = 1000;

// Timing variable
unsigned long previousMillis = 0;

// Track last known signal state
int lastSignalState = -1; // Initialize to invalid state to force first update

// -----------------------------------------------------------------------------
// Display CONTROL SIGNAL state on the E-Ink Paper
// -----------------------------------------------------------------------------
void displayControlSignal(int state) {
  char buffer[40];

  // Prepare image buffer
  Paint_NewImage(ImageBW, EPD_W, EPD_H, Rotation, WHITE);
  Paint_Clear(WHITE);

  // Display text according to input state
  if (state == HIGH) {
    sprintf(buffer, "CONTROL SIGNAL : ON");
  } else {
    sprintf(buffer, "CONTROL SIGNAL : OFF");
  }

  // Display text on E-Ink
  EPD_ShowString(30, 60, buffer, 24, BLACK);

  // Perform partial update (minimizes flicker)
  EPD_Display(ImageBW);
  EPD_PartUpdate();
}

// -----------------------------------------------------------------------------
// Setup
// -----------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);

  // Power control pin for the E-Ink display
  pinMode(7, OUTPUT);
  digitalWrite(7, HIGH);

  // Configure GPIO input pin (signal from Arduino)
  pinMode(EInk_GPIO3_Pin, INPUT);

  // Initialize E-Ink display
  EPD_GPIOInit();
  EPD_FastMode1Init();

  // Clear display initially
  Paint_NewImage(ImageBW, EPD_W, EPD_H, Rotation, WHITE);
  Paint_Clear(WHITE);
  EPD_Display(ImageBW);
  EPD_Update();

  previousMillis = millis();
}

// -----------------------------------------------------------------------------
// Loop — update display when input signal changes
// -----------------------------------------------------------------------------
void loop() {
  unsigned long currentMillis = millis();

  // Check input state at the specified interval
  if (currentMillis - previousMillis >= checkInterval) {
    previousMillis = currentMillis;

    int currentState = digitalRead(EInk_GPIO3_Pin);

    // Update display only when state changes
    if (currentState != lastSignalState) {
      displayControlSignal(currentState);

      // Debug output
      Serial.print("Arduino Output: ");
      Serial.print(currentState == HIGH ? "HIGH  " : "LOW   ");
      Serial.print("=> Display: ");
      Serial.println(currentState == HIGH ? "CONTROL SIGNAL : ON" : "CONTROL SIGNAL : OFF");

      lastSignalState = currentState;
    }
  }
}
