#include <math.h>

const float freq = 1000.0f;
const int   N    = 256;     // 256 samples per cycle
const uint32_t Ts_us = (uint32_t)llroundf(1e6f / (freq * N));

uint16_t lut[N];            // sine wave lookup table

float amplitude = 1800.0;   // adjustable amplitude (DAC counts)

void setup() {

  analogWriteResolution(12);   // configure DAC for 12-bit resolution

  // Generate sine lookup table
  for (int i = 0; i < N; ++i){
      lut[i] = 2048 + (amplitude * sin(2 * PI * i / N));
  }

}

void loop() {

  static uint32_t t_next = micros();

  for (int i = 0; i < N; ++i) {

    analogWrite(DAC0, lut[i]);   // output sinewave sample to DAC

    t_next += Ts_us;

    while ((int32_t)(micros() - t_next) < 0) {
      // precise timing wait
    }

  }

}
